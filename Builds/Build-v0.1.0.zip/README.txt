IMPORTANT NOTES:
-In order to use this program you first have to set a valid path in the .config file for the savefiles the program creates!
--> I will add something to do this automatically in future versions.

-The main window will currently allways show up somewhere in the left corner of your screen and is NOT movable or resizable.

-Setting the custom savepath in the settings will currently not delete existing savefiles from the previous directory nor will it change the .config file that contains the path from where savefiles are loaded!
But savefiles will be saved in that directory when the program is closed.

Have Fun :)
