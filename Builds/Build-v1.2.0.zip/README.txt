IMPORTANT NOTES:
-The main window will currently allways show up somewhere in the left corner of your screen and is NOT movable or resizable.


Have Fun :)
